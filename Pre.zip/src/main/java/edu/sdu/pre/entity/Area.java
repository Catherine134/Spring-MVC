package edu.sdu.pre.entity;

import java.io.Serializable;

public class Area implements Serializable{
	
	/**
	 * ������ʵ����
	 */
	private static final long serialVersionUID = 580542474515346230L;
	private Integer id;
	private String cityCode;
	private String areaCode;
	private String areaName;
	public Area() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Area(Integer id, String cityCode, String areaCode, String areaName) {
		super();
		this.id = id;
		this.cityCode = cityCode;
		this.areaCode = areaCode;
		this.areaName = areaName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Area [id=" + id + ", cityCode=" + cityCode + ", areaCode=" + areaCode + ", areaName=" + areaName + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Area other = (Area) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
}
