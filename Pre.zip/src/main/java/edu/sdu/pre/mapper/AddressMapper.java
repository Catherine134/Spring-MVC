package edu.sdu.pre.mapper;

import java.util.List;

import edu.sdu.pre.entity.Address;

public interface AddressMapper {

	List<Address> findAddressByUid(Integer uid);

	Address findCertainAddress(String recvName, String recvDistrict, String recvArea, String recvPhone);

	int saveAddress(Address address);

	int deleteAddressById(Integer id);

	Address findAddressById(Integer id);

	int updateAddressById(Integer id, String recvName, String recvProvince, String recvCity, String recvArea,
			String recvDistrict, String recvAddr, String recvPhone, String recvTel, String recvZip, String recvTag,
			String name, String time);

}
