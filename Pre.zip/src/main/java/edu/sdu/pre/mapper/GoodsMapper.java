package edu.sdu.pre.mapper;

import java.util.List;

import edu.sdu.pre.entity.Goods;

public interface GoodsMapper {

	List<Goods> findGoodsByCategory(Integer categoryId);
}
