package edu.sdu.pre.mapper;

import java.util.List;

import edu.sdu.pre.entity.Area;
import edu.sdu.pre.entity.City;
import edu.sdu.pre.entity.Province;

public interface DistrictMapper {

	Province findProvince(String recvProvince);

	City findCity(String recvCity);

	Area findArea(String recvArea);

	List<Province> findAllProvince();

	List<City> findCitiesByProvince(String provinceCode);

	List<Area> findAreasByCity(String cityCode);

}
