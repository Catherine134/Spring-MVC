package edu.sdu.pre.mapper;

import java.util.List;

import edu.sdu.pre.entity.GoodsCategory;
public interface GoodsCategoryMapper {

	List<GoodsCategory> getCategories(Integer rootId);

	GoodsCategory findGoodsCategoryById(Integer rootId);
}
