package edu.sdu.pre.controller;

import java.util.List;
import java.util.Locale.Category;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import edu.sdu.pre.entity.Goods;
import edu.sdu.pre.entity.GoodsCategory;
import edu.sdu.pre.service.IGoodsCategoryService;
import edu.sdu.pre.service.IGoodsService;

@Controller
@RequestMapping("/page")
public class PageController {

	@Resource
	private IGoodsCategoryService goodsCategoryService;
	
	@Resource
	private IGoodsService goodsService;
	
	@RequestMapping("/index.do")
	public String index(){
		return "index";
	}
	
	@RequestMapping("/orders.do")
	public String orders(){
		return "orders";
	}
	
	@RequestMapping("/favorites.do")
	public String favorites(){
		return "favorites";
	}
	
	/**
	 * 
	 * ������Ӧ��Ʒ�б�����
	 */
	@RequestMapping("/list.do")
	public String list(Integer categoryId,ModelMap map){
		
		GoodsCategory category=goodsCategoryService.findCategory(categoryId);
		GoodsCategory branch=goodsCategoryService.findCategory(category.getParentId());
		GoodsCategory root=goodsCategoryService.findCategory(branch.getParentId());
		
		List<Goods> list =goodsService.findGoodsByCategory(categoryId);
		
		map.put("root", root);
		map.put("branch", branch);
		map.put("category", category);
		map.put("goods", list);
		
		return "goodsList";
	}
	
}
