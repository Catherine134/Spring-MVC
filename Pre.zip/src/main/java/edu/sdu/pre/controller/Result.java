package edu.sdu.pre.controller;

import java.io.Serializable;

public class Result implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -472284638567855694L;
	
	public static final int SUCCESS=1;
	public static final int ERROR=0;
	
	private int state=SUCCESS;
	private String message="OK";
	private Object data=null;
	
	public Result(int state, String message, Object data) {
		super();
		this.state = state;
		this.message = message;
		this.data = data;
	}

	public Result() {
	
	}

	public Result(Object obj) {
		this(SUCCESS,"",obj);
	}
	public Result(Throwable e){
		state=ERROR;
		message=e.getMessage();
	}
	
	public Result(String successMessage){
		state=SUCCESS;
		message=successMessage;
	}
	
	@Override
	public String toString() {
		return "Result [state=" + state + ", message=" + message + ", data=" + data + "]";
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}
