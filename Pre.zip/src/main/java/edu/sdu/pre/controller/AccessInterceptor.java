package edu.sdu.pre.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import edu.sdu.pre.entity.User;
import jdk.nashorn.internal.ir.RuntimeNode.Request;

@Component
public class AccessInterceptor implements HandlerInterceptor {

	public AccessInterceptor() {
	}

	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		}

	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
	}

	public boolean preHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2) throws Exception {
		HttpSession session=arg0.getSession();
		User user=(User)session.getAttribute("loginUser");
		if(user==null){
			//û�е�¼���ض��򵽵�¼����
			String path=arg0.getServletContext().getContextPath();
			String  url=path+"/web/login.html";
			arg1.sendRedirect(url);
			return false;
		}else{
			
			return true;
		}
		
	}

}
