package edu.sdu.pre.controller;

import java.io.File;
import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import edu.sdu.pre.entity.User;
import edu.sdu.pre.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController extends BaseController {
	
	
	@Resource
	IUserService userService;
	
	@RequestMapping("/regist.do")
	@ResponseBody //SpringMVC�ṩ��ע�⣬������ֵ��䵽��Ӧ��Body��
	//������ֵ��JavaBeanʱ���Զ�ת��ΪJSON����
	public Result regist(String name, String password, String confirm, String email, String mobile){
		userService.regist(name, password, confirm, email, mobile);
		System.out.println("regist()");
		return new Result("�ɹ�");
	}

	@RequestMapping("/checkName.do")
	@ResponseBody //SpringMVC�ṩ��ע�⣬������ֵ��䵽��Ӧ��Body��
	//������ֵ��JavaBeanʱ���Զ�ת��ΪJSON����
	public Result checkName(String name){
		if(userService.existUser(name)){
			return new Result(Result.ERROR,"�û��Ѿ�����",null);
		}else{
			return new Result(Result.SUCCESS,"���ͨ��",null);
		}
		
	}
	
	@RequestMapping("/login.do")
	@ResponseBody
	public Result login(String name,String password,HttpSession session){
		User user=userService.login(name, password);
		session.setAttribute("loginUser", user);
		session.setAttribute("loginName", name);
		String uname=(String) session.getAttribute("loginName");//��ȡ�û�����
		//�����û����������û�id
		Integer uid=userService.findUidByName(uname);
		//System.out.println(uid);
		session.setAttribute("loginId", uid);
		return new Result("��¼�ɹ�");
	}
	
	/**
	 * �����ļ�����
	 */
	@RequestMapping(value="/upload.do", method=RequestMethod.POST)
	@ResponseBody
	public Result upload(String name, MultipartFile image1, MultipartFile image2 )
		throws IOException {
		
		System.out.println(name);
		
		String file1 = image1.getOriginalFilename();
		String file2 = image2.getOriginalFilename();
		
		File dir = new File("E:/Acc/upload");
		dir.mkdir();
			
		image1.transferTo(new File(dir, file1));
		image2.transferTo(new File(dir, file2));
		
		return new Result("OK");
	}
	
	/**
	 * �����ļ�����
	 */
	@RequestMapping(value="/upload2.do", method=RequestMethod.POST)
	@ResponseBody
	public Result upload2(String name, MultipartFile[] images )
		throws IOException {
		
		System.out.println(name);
		
		File dir = new File("E:/upload");
		dir.mkdir();
			
		for (MultipartFile multipartFile : images) {
			String file = multipartFile.getOriginalFilename();
			multipartFile.transferTo(new File(dir, file));
		}
		 
		return new Result("OK");
	}
}
