package edu.sdu.pre.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

public abstract class BaseController {

	public BaseController() {
		super();
	}

	/**
	 * SpringMVC�쳣����,����try-catch
	 * @param e
	 * @return
	 */
	@ExceptionHandler
	@ResponseBody
	public Result handleException(Exception e) {
		e.printStackTrace();
		return new Result(e);
	}

}