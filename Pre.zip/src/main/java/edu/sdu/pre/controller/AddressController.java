package edu.sdu.pre.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import edu.sdu.pre.entity.Address;
import edu.sdu.pre.entity.Area;
import edu.sdu.pre.entity.City;
import edu.sdu.pre.entity.Province;
import edu.sdu.pre.service.IAddressService;
import edu.sdu.pre.service.IDistrictService;

@Controller
@RequestMapping("/address")
public class AddressController {
	
	@Resource
	private IAddressService addressService;
	@Resource 
	private IDistrictService districtService;
	
	/*@RequestMapping("/addressShow.do")
	@ResponseBody
	public Result addressShow(HttpSession session){
		Integer Uid=(Integer) session.getAttribute("loginId");
		System.out.println(Uid);
		List<Address> list=addressService.findAllAddress(Uid);
		return new Result(list);
	}*/
	/**
	 * ����һ����ַ��Ϣ
	 * @param session
	 * @param recvName
	 * @param recvProvince
	 * @param recvCity
	 * @param recvArea
	 * @param recvAddr
	 * @param recvPhone
	 * @param recvTel
	 * @param recvZip
	 * @param recvTag
	 * @return
	 */
	@RequestMapping("/save.do")
	@ResponseBody
	public Result save(HttpSession session,String recvName, String recvProvince, String recvCity, String recvArea,
			String recvAddr, String recvPhone, String recvTel, String recvZip, String recvTag){
		Integer Uid=(Integer)session.getAttribute("loginId");
		String  name=(String) session.getAttribute("loginName");
		addressService.save(Uid,recvName,recvProvince,recvCity,recvArea,recvAddr,recvPhone,recvTel,recvZip,recvTag,name);
		List<Address> list =addressService.findAllAddress(Uid);
		return new Result(list);
	}

	/**
	 * ��ַ���������ʼ��
	 * @param session
	 * @param map
	 * @return
	 */
	@RequestMapping("/addressAdmin.do")
	public String addressAdmin(HttpSession session,ModelMap map){
		Integer Uid=(Integer) session.getAttribute("loginId");
		System.out.println(Uid);
		List<Address> list=addressService.findAllAddress(Uid);
		map.put("address", list);
		
		List<Province> provinceList=districtService.findAllProvince();
		map.put("provinces", provinceList);
		
		return "addressAdmin";
	}
	/**
	 * ��ȡĳһʡ�ݵ�ȫ������
	 * @param provinceCode
	 * @return
	 */
	@RequestMapping("/city.do")
	@ResponseBody
	public Result city(String provinceCode){
		List<City> cities=districtService.findCityOfProvince(provinceCode);
		return new Result(cities);
	}
	/**
	 * ��ȡĳһ���е�����
	 * @param cityCode
	 * @return
	 */
	@RequestMapping("/area.do")
	@ResponseBody
	public Result area(String cityCode){
		List<Area> areas=districtService.findAreaOfCity(cityCode);
		return new Result(areas);
	}
	/**
	 * ɾ��һ����ַ��Ϣ
	 * @param session
	 * @param id
	 * @param map
	 * @return
	 */
	@RequestMapping("/delete.do")
	public String delete(HttpSession session,Integer id,ModelMap map){
		addressService.deleteAddress(id);
		
		Integer Uid=(Integer) session.getAttribute("loginId");
		System.out.println(Uid);
		List<Address> list=addressService.findAllAddress(Uid);
		map.put("address", list);
		
		List<Province> provinceList=districtService.findAllProvince();
		map.put("provinces", provinceList);
		
		return "addressAdmin";
	}
	/**
	 * ת����Ϣ�޸Ľ���
	 * @param session
	 * @param id
	 * @param map
	 * @return
	 */
	@RequestMapping("/update.do")
	public String  update(HttpSession session,Integer id,ModelMap map){
		Address address=addressService.findAddress(id);
		map.put("update", address);
		
		Integer Uid=(Integer) session.getAttribute("loginId");
		System.out.println(Uid);
		List<Address> list=addressService.findAllAddress(Uid);
		map.put("address", list);
		
		List<Province> provinceList=districtService.findAllProvince();
		map.put("provinces", provinceList);
		
		return "addressUpdate";
		
	}
	/**
	 * ����һ����ַ��Ϣ
	 * @param session
	 * @param id
	 * @param recvName
	 * @param recvProvince
	 * @param recvCity
	 * @param recvArea
	 * @param recvAddr
	 * @param recvPhone
	 * @param recvTel
	 * @param recvZip
	 * @param recvTag
	 * @return
	 */
	@RequestMapping("/change.do")
	@ResponseBody
	public Result change(HttpSession session,Integer id,String recvName, String recvProvince, String recvCity, String recvArea,
			String recvAddr, String recvPhone, String recvTel, String recvZip, String recvTag){
		Integer Uid=(Integer)session.getAttribute("loginId");
		String  name=(String) session.getAttribute("loginName");
		addressService.updateAddress(id,recvName,recvProvince,recvCity,recvArea,recvAddr,recvPhone,recvTel,recvZip,recvTag,name);
		List<Address> list =addressService.findAllAddress(Uid);
		return new Result(list);
	}
}
