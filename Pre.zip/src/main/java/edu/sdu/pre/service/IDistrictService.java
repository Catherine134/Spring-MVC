package edu.sdu.pre.service;

import java.util.List;

import edu.sdu.pre.entity.Area;
import edu.sdu.pre.entity.City;
import edu.sdu.pre.entity.Province;

public interface IDistrictService {

	List<Province> findAllProvince();

	List<City> findCityOfProvince(String provinceCode);

	List<Area> findAreaOfCity(String cityCode);

}
