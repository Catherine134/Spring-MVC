package edu.sdu.pre.service;

import edu.sdu.pre.entity.User;
import edu.sdu.pre.service.ex.NullValueException;
import edu.sdu.pre.service.ex.PassworException;
import edu.sdu.pre.service.ex.UserExistException;
import edu.sdu.pre.service.ex.UserNameException;

public interface IUserService {

	/**
	 * ע���û�
	 * @param name
	 * @param password
	 * @param confirm
	 * @param email
	 * @param mobile
	 * @throws UserExistException �û��������쳣
	 * @throws PassworException	�������
	 */
	void regist(String name,String password,String confirm,String email,String mobile)
		throws UserExistException,PassworException;

	boolean existUser(String name);

	User login(String name, String password) throws PassworException, UserNameException;
	
	public void deleteUsers(Integer... id);

	Integer findUidByName(String uname);
}
