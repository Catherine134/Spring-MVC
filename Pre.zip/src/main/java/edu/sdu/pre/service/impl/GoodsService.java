package edu.sdu.pre.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import edu.sdu.pre.entity.Goods;
import edu.sdu.pre.entity.GoodsCategory;
import edu.sdu.pre.mapper.GoodsCategoryMapper;
import edu.sdu.pre.mapper.GoodsMapper;
import edu.sdu.pre.service.IGoodsService;
import edu.sdu.pre.service.ex.ServiceException;

@Service
public class GoodsService implements IGoodsService{
	
	@Resource
	private GoodsMapper goodsMapper;
	
	@Resource 
	private GoodsCategoryMapper goodsCategoryMapper;
	
	public List<Goods> findGoodsByCategory(Integer categoryId) {
		
		GoodsCategory category=goodsCategoryMapper.findGoodsCategoryById(categoryId);
		
		if(category==null){
			throw new ServiceException("����ID����");
		}
		return goodsMapper.findGoodsByCategory(categoryId);
	}

}
