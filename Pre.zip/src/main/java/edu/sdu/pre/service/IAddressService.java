package edu.sdu.pre.service;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.sdu.pre.entity.Address;
import edu.sdu.pre.entity.User;

@Service
public interface IAddressService {

	List<Address> findAllAddress(Integer uid);

	void save(Integer uid, String recvName, String recvProvince, String recvCity, String recvArea, String recvAddr,
			String recvPhone, String recvTel, String recvZip, String recvTag,String names);

	void deleteAddress(Integer id);

	Address findAddress(Integer id);

	void updateAddress(Integer id, String recvName, String recvProvince, String recvCity, String recvArea,
			String recvAddr, String recvPhone, String recvTel, String recvZip, String recvTag, String name);

}
