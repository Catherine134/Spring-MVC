package edu.sdu.pre.service;

import java.util.List;

import edu.sdu.pre.entity.Goods;

public interface IGoodsService {

	List<Goods> findGoodsByCategory(Integer categoryId);
}
