package edu.sdu.pre.service;

import java.util.List;

import edu.sdu.pre.entity.GoodsCategory;

public interface IGoodsCategoryService {

	List<GoodsCategory> findCategories(Integer rootId);

	GoodsCategory findCategory(Integer parentId);
}
