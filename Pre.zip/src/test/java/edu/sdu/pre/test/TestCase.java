package edu.sdu.pre.test;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.sdu.pre.entity.Goods;
import edu.sdu.pre.entity.GoodsCategory;
import edu.sdu.pre.entity.User;
import edu.sdu.pre.mapper.GoodsCategoryMapper;
import edu.sdu.pre.mapper.UserMapper;
import edu.sdu.pre.service.IGoodsService;
import edu.sdu.pre.service.IUserService;

public class TestCase {

	ClassPathXmlApplicationContext ctx;
	
	@Before
	public void Init(){
		//���������������ļ�
		ctx=new ClassPathXmlApplicationContext("spring-mybatis.xml","spring-service.xml");
	}
	@After
	public void destroy(){
		ctx.close();
	}
	@Test
	public void testAddUser(){
		UserMapper mapper=ctx.getBean("userMapper",UserMapper.class);
		
		User user=new User(1,"Tom","123","110","119",1,"Tom","20180711","Tom","20180711");
		
		int n=mapper.addUser(user);
		
		System.out.println(n);
	}
	@Test
	public void testRegist(){
		IUserService service=ctx.getBean("userService",IUserService.class);
		service.regist("Tom", "123", "123", "111@163.com", "43699");
		
	}
	@Test
	public void testGetCategories(){
		GoodsCategoryMapper mapper=ctx.getBean("goodsCategoryMapper",GoodsCategoryMapper.class);
		List<GoodsCategory> list=mapper.getCategories(161);
		for(GoodsCategory goodsCategory:list){
			System.out.println(goodsCategory);
		}
	}
	@Test
	public void testFindGoodsByCategory(){
		IGoodsService service=ctx.getBean("goodsService",IGoodsService.class);
		List<Goods> list=service.findGoodsByCategory(163);
		for(Goods good:list){
			System.out.println(good);
		}
	}
	@Test
	public void hashTest(){
		String str = "123123";
		String md5 = DigestUtils.md5Hex(str);
		System.out.println(md5); 
		str = "123124";
		md5 = DigestUtils.md5Hex(str);
		System.out.println(md5); 
		
		str = "123124��������ˆ�";
		md5 = DigestUtils.md5Hex(str);
		System.out.println(md5); 
	}
	@Test
	public void testDeleteUserById(){
		UserMapper mapper=ctx.getBean("userMapper",UserMapper.class);
		mapper.deleteUserById(4);
	}
	@Test
	public void testDeleteUsers(){
		IUserService service=ctx.getBean("userService",IUserService.class);
		service.deleteUsers(2,3);//��ɾ��ʧ�ܣ�idΪ100�޷�ɾ����������ع������еĶ��޷�ɾ��
	}
	@Test
	public void testFindUserId(){
		IUserService service=ctx.getBean("userService",IUserService.class);
		Integer id=service.findUidByName("alice1");
		System.out.println(id);
	}

}
