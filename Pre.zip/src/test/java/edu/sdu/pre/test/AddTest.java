package edu.sdu.pre.test;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.sdu.pre.entity.Address;
import edu.sdu.pre.entity.City;
import edu.sdu.pre.entity.Province;
import edu.sdu.pre.mapper.AddressMapper;
import edu.sdu.pre.mapper.DistrictMapper;
import edu.sdu.pre.service.IAddressService;
import edu.sdu.pre.service.impl.AddressService;



public class AddTest {

ClassPathXmlApplicationContext ctx;
	
	@Before
	public void Init(){
		//���������������ļ�
		ctx=new ClassPathXmlApplicationContext("spring-mybatis.xml","spring-service.xml");
	}
	@After
	public void destroy(){
		ctx.close();
	}
	
	@Test
	public void mtestFindAddressByUid(){
		IAddressService service=ctx.getBean("addressService",AddressService.class);
		List<Address> list=service.findAllAddress(11);
		for(Address add:list){
			System.out.println(add);
		}
	}
	@Test 
	public void stestFindAddressByUid(){
		IAddressService service=ctx.getBean("addressService",AddressService.class);
		List<Address> list=service.findAllAddress(11);
		for(Address add:list){
			System.out.println(add);
		}
	}
	@Test
	public void dictTest(){
		DistrictMapper mapper=ctx.getBean("districtMapper",DistrictMapper.class);
		
		Province pro=mapper.findProvince("370000");
		
		System.out.println(pro);
		
		City city=mapper.findCity("371000");
		System.out.println(city.getCityName());
		
	}
	
	@Test 
	public void stestSave(){
		IAddressService service=ctx.getBean("addressService",AddressService.class);
		
		service.save(11,"��Сΰ", "370000", "371000", "371002", "�Ļ���·180��", "12345678901", "", "264209","����","��ΰ");
	}
	@Test
	public void mtestSave(){
		
		AddressMapper mapper=ctx.getBean("addressMapper",AddressMapper.class);
		
		Address add=new Address(null, 11, "��Сΰ", "370000", "371000", "371002", "ɽ��ʡ�����л�����", "�Ļ���·180��", "12345678901", "", "264209","����", 0,"��ΰ", "20180721","��ΰ", "20180721");
		
		int n=mapper.saveAddress(add);
		System.out.println(n);
	}

}
